from flask import Flask, flash, redirect, url_for, request, render_template, session
from database import execute_query, fetch_all, fetch_one

app = Flask(__name__)
app.secret_key = "secret"
@app.route('/')
def home():
    return render_template('2/index.html')
@app.route('/register-select')
def register_select():
    return render_template('2/register-select.html')
@app.route('/worker-register')
def worker_register():
    return render_template('2/worker-register.html')
@app.route('/employer-register')
def employer_register():
    return render_template('2/employer-register.html')
@app.route('/job_create')
def job_create():
    return render_template('2/job_create.html')
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))
@app.route('/choose', methods=['POST'])
def choose():
    user_type_reg = request.form.get("action")
    if user_type_reg == "worker":
        return redirect(url_for("edit_profile"))
    elif user_type_reg == "employer":
        return redirect(url_for("employer_register"))
@app.route("/add_worker/<int:user_id>", methods=['POST'])
@app.route('/add_worker', methods=['POST'])
def add_worker(user_id=None):
    email = request.form['email']
    password = request.form['password']
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    phone = request.form['phone']
    education = request.form['education']
    experience = request.form['experience']
    profession = request.form['profession']
    skills = request.form['skills']
    languages = request.form['languages']
    expected_salary = request.form['expected_salary']
    work_schedule = request.form['work_schedule']
    print(user_id)

    if "user_id" not in session:
        query = "INSERT INTO workers (email, password, first_name, last_name, phone, education, experience, profession, skills, languages, expected_salary, work_schedule) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
        success = execute_query(query, (email, password, first_name, last_name, phone, education, experience, profession, skills, languages, expected_salary, work_schedule, ))
        if success:
            flash("Сіз тіркелдіңіз!", "success")
            return redirect(url_for("home"))
        else:
            flash("Қате!", "error")
            return redirect(url_for("home"))
    else:
        if session["role"] =="admins":
            user_id2 = user_id
        else:
            user_id2 = session["user_id"][0]
        query = """
        UPDATE workers
        SET
            email = ?,
            password = ?,
            first_name = ?,
            last_name = ?,
            phone = ?,
            education = ?,
            experience = ?,
            profession = ?,
            skills = ?,
            languages = ?,
            expected_salary = ?,
            work_schedule = ?
        WHERE user_id = ?
        """
        params = (
            email, password, first_name, last_name, phone,
            education, experience, profession, skills, languages,
            expected_salary, work_schedule, user_id2
        )
        success = execute_query(query, params)
        if success:
            flash("Сіз профильді жаңарттыңыз!", "success")
            return redirect(url_for("profile"))
        else:
            flash("Қате 404!", "error")
            return redirect(url_for("profile"))
@app.route("/add_employer/<int:user_id>", methods=['POST'])
@app.route('/add_employer', methods=['POST'])
def add_employer(user_id=None):
    company_name = request.form['company_name']
    email = request.form['email']
    password = request.form['password']
    phone = request.form['phone']
    company_address = request.form['company_address']
    industry = request.form['industry']
    company_description = request.form['company_description']
    company_website = request.form['company_website']
    business_registration_number = request.form['business_registration_number']

    if "user_id" not in session:
        query = "INSERT INTO employers (company_name, email, password, phone, company_address, industry, company_description, company_website, business_registration_number) VALUES (?,?,?,?,?,?,?,?,?)"
        success = execute_query(query, (company_name, email, password, phone, company_address, industry, company_description, company_website, business_registration_number))

        if success:
            flash("Сіз тіркелдіңіз!", "success")
            return redirect(url_for("home"))
        else:
            flash("Қате 404!", "error")
            return redirect(url_for("home"))
    else:
        if session["role"] =="admins":
            user_id2 = user_id
        else:
            user_id2 = session["user_id"][0]
        query = """
        UPDATE employers
        SET
            company_name = ?,
            email = ?,
            password = ?,
            phone = ?,
            company_address = ?,
            industry = ?,
            company_description = ?,
            company_website = ?,
            business_registration_number = ?
        WHERE user_id = ?
        """
        params = (
            company_name, email, password, phone, company_address,
            industry, company_description, company_website, business_registration_number, user_id2
        )
        success = execute_query(query, params)
        if success:
            flash("Сіз профильді жаңарттыңыз!", "success")
            return redirect(url_for("profile"))
        else:
            flash("Қате 404!", "error")
            return redirect(url_for("profile"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        tables = ["workers", "employers", "admins"]
        user = None

        for table in tables:
            query = f"SELECT password FROM {table} WHERE email = ?"
            result = fetch_one(query, (email,))
            
            if result:
                query = f"SELECT user_id FROM {table} WHERE email = ? AND password = ?"
                session["user_id"] = fetch_one(query,(email,password,))
                user = result[0]
                session["role"] = table
                break

        if not user:
            flash("Қолданушы табылмады!", "error")
            return redirect(url_for("login"))

        if password != user:
            flash("Қате пароль!", "error")
            return redirect(url_for("login"))

        return redirect(url_for("profile"))
    return render_template("2/login.html")
@app.route("/profile")
def profile():
    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id2 = session["user_id"][0]
    role = session["role"]
    user = fetch_one(f"SELECT * FROM {role} WHERE user_id = ?",(user_id2,))
    if role == "workers":
        user_data = {
            "user_id": user[0],
            "email": user[1],
            "password": user[2],
            "first_name": user[3],
            "last_name": user[4],
            "phone": user[5],
            "education": user[6],
            "experience": user[7],
            "profession": user[8],
            "skills": user[9],
            "languages": user[10],
            "expected_salary": user[11],
            "work_schedule": user[12]
        }
        return render_template("2/worker-dashboard.html", user=user_data)
    elif role == "employers":
        quer = fetch_one(f"""
            SELECT
                (SELECT COUNT(*) FROM clicked WHERE user_id = ?) AS total_applicants,
                (SELECT COUNT(*) FROM clicked 
                 WHERE user_id = ? 
                   AND work_id = (SELECT work_id FROM clicked WHERE user_id = ? ORDER BY click_date DESC LIMIT 1)
                ) AS job_applicants,
                (SELECT COUNT(*) FROM works WHERE user_id = ?) AS total_jobs,
                (SELECT profession FROM works 
                 WHERE user_id = ? 
                   AND work_id = (SELECT work_id FROM clicked WHERE user_id = ? ORDER BY click_date DESC LIMIT 1)
                ) AS job_name
        """, (user_id2, user_id2, user_id2, user_id2, user_id2, user_id2))

        user_data = {
            "company_name": user[1],
            "email": user[2],
            "password": user[3],
            "phone": user[4],
            "company_address": user[5],
            "industry": user[6],
            "company_description": user[7],
            "company_website": user[8],
            "business_registration_number": user[9],
            "total_applicants": quer[0],
            "job_applicants": quer[1],
            "total_jobs": quer[2],
            "job_name": quer[3]
        }
        return render_template("2/employer-dashboard.html", user=user_data)
    else:
        quer = fetch_one("""
        SELECT
            (SELECT COUNT(*) FROM workers) AS workers_count,
            (SELECT COUNT(*) FROM employers) AS employers_count,
            (SELECT COUNT(*) FROM works) AS works_count,
            (SELECT name_admin FROM admins WHERE user_id = ?) AS works_count
        """,(user_id2,))
        user_data = {
            "name_admin": quer[3],
            "email": user[0],
            "password": user[1],
            "total_workers": quer[0],
            "total_employers": quer[1],
            "total_jobs": quer[2]
        }
        return render_template("2/admin-dashboard.html", user=user_data)

@app.route("/edit_profile/<int:user_id>/<role>")
@app.route("/edit_profile")
def edit_profile(user_id = None, role = None):
    if "user_id" not in session:
        return redirect(url_for("login"))
    if session["role"] == "admins":
        user_id2 = user_id
        print(user_id2)
    else:
        user_id2 = session["user_id"][0]
        role = session["role"]
    user = fetch_one(f"SELECT * FROM {role} WHERE user_id = ?",(user_id2,))
    if role == "workers":
        user_data = {
            "email": user[1],
            "password": user[2],
            "first_name": user[3],
            "last_name": user[4],
            "phone": user[5],
            "education": user[6],
            "experience": user[7],
            "profession": user[8],
            "skills": user[9],
            "languages": user[10],
            "expected_salary": user[11],
            "work_schedule": user[12]
        }
        return render_template("2/change_worker_profile.html", user=user_data, user_id=user_id2)
    elif role == "employers":
        user_data = {
            "company_name": user[1],
            "email": user[2],
            "password": user[3],
            "phone": user[4],
            "company_address": user[5],
            "industry": user[6],
            "company_description": user[7],
            "company_website": user[8],
            "business_registration_number": user[9]
        }
        return render_template("2/change_employer_profile.html", user=user_data, user_id=user_id2)
@app.route("/add_job/<int:user_id>/<int:job_id>", methods=["GET", "POST"])
@app.route("/add_job/<int:user_id>", methods=["GET", "POST"])
@app.route("/add_job", methods=["GET", "POST"])
def add_job(user_id = None, job_id = None):
    if "user_id" not in session:
        return redirect(url_for("login"))
    work_schedule = request.form['work_schedule']
    profession = request.form['profession']
    salary = request.form['salary']
    experience = request.form['experience']
    education = request.form['education']
    working_hours = request.form['working_hours']
    job_description = request.form['job_description']
    requirements = request.form['requirements']
    benefits = request.form['benefits']
    if job_id == None:
        user_id = session["user_id"]
        query = "INSERT INTO works (work_schedule, profession, salary, experience, education, working_hours, job_description, requirements, benefits, user_id) VALUES (?,?,?,?,?,?,?,?,?,?)"
        success = execute_query(query, (work_schedule, profession, salary, experience, education, working_hours, job_description, requirements, benefits, user_id[0]))
        if success:
            flash("Жұмыс тіркелді!", "success")
            return redirect(url_for("profile"))
        else:
            flash("Қате 404!", "error")
            return redirect(url_for("profile"))
    else:
        query = """
        UPDATE works
        SET
            work_schedule = ?,
            profession = ?,
            salary = ?,
            experience = ?,
            education = ?,
            working_hours = ?,
            job_description = ?,
            requirements = ?,
            benefits = ?,
            user_id = ?
        WHERE work_id = ?
        """
        params = (
            work_schedule, profession, salary, experience, education,
            working_hours, job_description, requirements, benefits, user_id, job_id
        )
        success = execute_query(query, params)
        if success:
            flash("Жұмыс жаңартылды!", "success")
            return redirect(url_for("profile"))
        else:
            flash("Қате 404!", "error")
            return redirect(url_for("profile"))


@app.route("/delete_account", methods=["POST"])
def delete_account():
    if "user_id" not in session:
        return redirect(url_for("login"))

    password = request.form["password"]
    user_id = session.get("user_id")
    role = session["role"]

    if role != "admins":
        success = fetch_one(f"SELECT password FROM {role} WHERE user_id = ?",(user_id,))
    else:
        return redirect(url_for("profile"))
    if success[0] == password:
        s = execute_query(f"DELETE FROM {role} WHERE user_id = ?",(user_id,))
        if s:
            flash("Сіздің аккаунт өшірілді:(", "success")
            return redirect(url_for("home"))
        else:
            flash("Қате 404!", "error")
            return redirect(url_for("profile"))
    else:
        flash("Қате пароль!", "error")
        return redirect(url_for("profile"))

@app.route("/jobs")
def jobs():
    if session["role"] == "employers":
        uid = session["user_id"][0]
        job_d = fetch_all("SELECT * FROM works WHERE user_id = ?",(uid,))
    elif session["role"] == "workers":
        job_d = fetch_all("SELECT * FROM works")
    jobs = []
    for i in range(len(job_d)):
        company = fetch_one("SELECT company_name FROM employers WHERE user_id = ?",(job_d[i][10],))
        jobs.append({
            "job_id": job_d[i][0],
            "work_schedule": job_d[i][1],
            "profession": job_d[i][2],
            "salary": job_d[i][3],
            "experience": job_d[i][4],
            "education": job_d[i][5],
            "working_hours": job_d[i][6],
            "job_description": job_d[i][7],
            "requirements": job_d[i][8],
            "benefits": job_d[i][9],
            "user_id": job_d[i][10],
            "company_name": company[0]
        })
    return render_template("2/jobs.html", jobs=jobs, role=session["role"])

@app.route("/job_details/<int:job_id>")
def job_details(job_id):
    job = fetch_one("SELECT * FROM works WHERE work_id = ?", (job_id,))
    if job:
        company = fetch_one("SELECT company_name FROM employers WHERE user_id = ?", (job[10],))
        job_data = {
            "job_id": job[0],
            "work_schedule": job[1],
            "profession": job[2],
            "salary": job[3],
            "experience": job[4],
            "education": job[5],
            "working_hours": job[6],
            "job_description": job[7],
            "requirements": job[8],
            "benefits": job[9],
            "user_id": job[10],
            "company_name": company[0],
        }
        has_applied = False
        clicked_info = None

        if "user_id" in session and session.get("role") == "workers":
            clicked = fetch_one(
                "SELECT clicked_id, user_id, work_id FROM clicked WHERE user_id = ? AND work_id = ?",
                (session["user_id"][0], job_id)
            )
            if clicked:
                has_applied = True
                clicked_info = {
                    "clicked_id": clicked[0],
                    "user_id": clicked[1],
                    "work_id": clicked[2]
                }
        return render_template("2/job-details.html", job=job_data, role=session.get("role"), has_applied=has_applied, clicked=clicked_info)
    else:
        return "Жұмыс табылмады", 404

@app.route("/apply/<int:job_id>")
def apply(job_id):
    job = fetch_one("SELECT work_id, profession, salary, experience, user_id FROM works WHERE work_id = ?", (job_id,))
    company = fetch_one("SELECT company_name FROM employers WHERE user_id = ?", (job[4],))
    res = {
        "job_id": job[0],
        "user_id": session["user_id"][0],
        "profession": job[1],
        "company_name": company[0],
        "salary": job[2],
        "experience": job[3]
    }
    return render_template('2/apply.html', res=res, role=session["role"])

@app.route("/applicants/<int:job_id>")
def applicants(job_id):
    workers = fetch_all("SELECT user_id FROM clicked WHERE work_id = ?", (job_id,))
    res = []
    for i in workers:
        worker = fetch_one("SELECT * FROM workers WHERE user_id = ?", (i[0],))
        res .append({
            "email": worker[1],
            "full_name": worker[3] + " " + worker[4],
            "phone": worker[5],
            "education": worker[6],
            "experience": worker[7],
            "profession": worker[8],
            "skills": worker[9],
            "languages": worker[10],
            "expected_salary": worker[11],
            "work_schedule": worker[12],
        })
    return render_template('2/apply.html', res=res, role=session["role"])
@app.route("/send_apply/<int:job_id>", methods=["POST"])
def send_apply(job_id):
    from datetime import datetime
    if "user_id" not in session:
        return redirect(url_for("login"))
    if session["role"] == "employers" :
        return redirect(url_for("login"))
    user_id = session["user_id"][0]
    wiwtj = request.form['wiwtj']
    click_date = datetime.today().date()
    success = execute_query("INSERT INTO clicked (user_id, work_id, wiwtj, click_date) VALUES (?,?,?,?)", (user_id,job_id,wiwtj,click_date))
    if success:
        flash("Нурда черт", "success")
        return redirect(url_for("profile"))
    else:
        flash("Қате 404!", "error")
        return redirect(url_for("profile"))
@app.route("/dell_apply/<int:clicked_id>")
@app.route("/dell_apply/<int:user_id>/<int:clicked_id>")
def dell_apply(clicked_id, user_id = None):
    if user_id == None:
        drop = execute_query("DELETE FROM clicked WHERE clicked_id = ?", (clicked_id,))
    else:
        drop = execute_query("DELETE FROM clicked WHERE clicked_id = ? AND user_id = ?", (clicked_id, user_id,))
    if drop:
        flash("Өтінім өшірілді", "success")
        return redirect(url_for("profile"))
    else:
        flash("Қате 404!", "error")
        return redirect(url_for("profile"))
@app.route("/dell_job/<int:job_id>")
def dell_job(job_id):
    drop2 = execute_query("DELETE FROM clicked WHERE work_id = ?",(job_id,))
    drop = execute_query("DELETE FROM works WHERE work_id = ?",(job_id,))
    if drop and drop2:
        flash("Вакансияңыз өшірілді!", "success")
        return redirect(url_for("profile"))
    else:
        flash("Қате 404!", "error")
        return redirect(url_for("profile"))

@app.route("/applied_jobs")
def applied_jobs():
    user_id = session["user_id"][0]
    job_d = fetch_all("SELECT w.* FROM works w JOIN clicked c ON w.work_id = c.work_id WHERE c.user_id = ?",(user_id,))
    jobs = []
    for i in range(len(job_d)):
        company = fetch_one(f"SELECT company_name FROM employers WHERE user_id = {job_d[i][10]}")
        jobs.append({
            "job_id": job_d[i][0],
            "work_schedule": job_d[i][1],
            "profession": job_d[i][2],
            "salary": job_d[i][3],
            "experience": job_d[i][4],
            "education": job_d[i][5],
            "working_hours": job_d[i][6],
            "job_description": job_d[i][7],
            "requirements": job_d[i][8],
            "benefits": job_d[i][9],
            "user_id": job_d[i][10],
            "company_name": company[0]
        })
    return render_template("2/jobs.html", jobs=jobs, role=session["role"])


@app.route("/admin_index")
def admin_index():
    employers = fetch_all("SELECT user_id, company_name FROM employers")
    workers = fetch_all("SELECT user_id, first_name, last_name FROM workers")
    return render_template("2/admin_index.html", workers=workers, employers=employers)
@app.route("/admin_worker/<int:user_id>")
def admin_worker(user_id):
    worker = fetch_one("SELECT * FROM workers WHERE user_id=?",(user_id,))
    applicants = fetch_all("SELECT * FROM clicked WHERE user_id=?",(user_id,))
    return render_template("2/admin_worker.html", worker=worker, applicants=applicants)
@app.route("/admin_employer/<int:user_id>")
def admin_employer(user_id):
    employer = fetch_one("SELECT * FROM employers WHERE user_id=?",(user_id,))
    jobs = fetch_all("SELECT * FROM works WHERE user_id=?",(user_id,))
    return render_template("2/admin_employer.html", employer=employer, jobs=jobs)

@app.route("/edit_job/<int:job_id>")
@app.route("/edit_job")
def edit_job(job_id):
    if "user_id" not in session:
        return redirect(url_for("login"))
    user = fetch_one(f"SELECT * FROM works WHERE work_id = ?", (job_id,))
    job_data = {
        "work_id": user[0],
        "work_schedule": user[1],
        "profession": user[2],
        "salary": user[3],
        "experience": user[4],
        "education": user[5],
        "working_hours": user[6],
        "job_description": user[7],
        "requirements": user[8],
        "benefits": user[9],
        "user_id": user[10]
    }
    return render_template("2/change_job.html", job=job_data)
    if success:
        flash("Вакансия жаңартылды!", "success")
        return redirect(url_for("profile"))
    else:
        flash("Қате 404!", "error")
        return redirect(url_for("profile"))
if __name__ == '__main__':
    app.run(debug=True)