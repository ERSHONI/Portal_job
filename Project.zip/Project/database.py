import sqlite3
from sqlite3 import Error

DB_PATH = "Project_work.db"

def create_connection():
    try:
        conn = sqlite3.connect(DB_PATH)
        return conn
    except Error as e:
        print("DB error:", e)
        return None

def execute_query(query, params=()):
    conn = create_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(query, params)
        conn.commit()
        conn.close()
        return True
    except Error as e:
        print("SQL Error:", e)
        print("Query:", query)
        conn.close()
        return False

def fetch_all(query, params=()):
    conn = create_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()
        return rows
    except Error as e:
        print("SQL Error:", e)
        conn.close()
        return []

def fetch_one(query, params=()):
    conn = create_connection()
    cursor = conn.cursor()
    try:
        cursor.execute(query, params)
        row = cursor.fetchone()
        conn.close()
        return row  # вернёт None, если не найдено
    except Error as e:
        print("SQL Error:", e)
        conn.close()
        return None
